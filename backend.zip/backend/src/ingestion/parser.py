import io
import pdfplumber
import docx

def parse_bytes(filename: str, data: bytes) -> str:
    name = filename.lower()
    if name.endswith('.pdf'):
        try:
            text = []
            with pdfplumber.open(io.BytesIO(data)) as pdf:
                for p in pdf.pages:
                    text.append(p.extract_text() or "")
            return "\n".join(text).strip()
        except Exception:
            return ""
    if name.endswith('.docx'):
        try:
            doc = docx.Document(io.BytesIO(data))
            return "\n".join([p.text for p in doc.paragraphs]).strip()
        except Exception:
            return ""
    try:
        return data.decode(errors="ignore")
    except Exception:
        return ""
