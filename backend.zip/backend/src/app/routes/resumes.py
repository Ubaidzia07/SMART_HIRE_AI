from fastapi import APIRouter, UploadFile, File, HTTPException
import os
from src.ingestion.parser import parse_bytes
from src.db.models.resume import Resume
from src.db.database import SessionLocal, engine, Base

# Ensure DB tables exist
Base.metadata.create_all(bind=engine)

router = APIRouter(
    prefix="/resumes",
    tags=["resumes"]
)

# Use your existing folder
UPLOAD_DIR = "src/resumes_uploaded"
os.makedirs(UPLOAD_DIR, exist_ok=True)  # optional, just in case

@router.post("/upload")
async def upload_resume(file: UploadFile = File(...)):
    file_location = os.path.join(UPLOAD_DIR, file.filename)
    
    # Save the uploaded file
    try:
        content = await file.read()  # read once
        with open(file_location, "wb") as f:
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {e}")
    
    # Extract text from the file
    try:
        text = parse_bytes(file.filename, content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract text: {e}")
    
    # Save metadata + extracted text to DB
    db = SessionLocal()
    resume = Resume(filename=file.filename, storage_path=file_location, text=text)
    db.add(resume)
    db.commit()
    db.refresh(resume)
    db.close()
    
    return {"id": resume.id, "filename": resume.filename, "path": resume.storage_path, "text_preview": text[:200]}
