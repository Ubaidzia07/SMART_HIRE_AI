from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.app.routes import resumes

app = FastAPI(title="SmartHire API")

# CORS settings: allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can restrict to your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include resumes routes
app.include_router(resumes.router)

@app.get("/health")
async def health():
    return {"status": "ok"}
